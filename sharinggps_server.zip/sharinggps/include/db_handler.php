<?php


class DbHandler {

    private $conn;

    function __construct() {
        require_once dirname(__FILE__) . '/db_connect.php';
        // opening db connection
        $db = new DbConnect();    
        $this->conn = $db->connect();
    }

    // creating new user if not existed
    public function createUser($name, $email) {
        $response = array();

        // First check if user already existed in db
        if (!$this->isUserExists($email)) {
            // insert query
            $stmt = $this->conn->prepare("INSERT INTO users(name, email) values(?, ?)");
            $stmt->bind_param("ss", $name, $email);

            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // User successfully inserted
                $response["error"] = false;
                $response["user"] = $this->getUserByEmail($email);
            } else 
                {
                // Failed to create user
                $response["error"] = true;
                $response["message"] = "Oops! An error occurred while registereing";
            }
        }
        else {
            // User with same email already existed in the db
            $response["error"] = false;
            $response["user"] = $this->getUserByEmail($email);
        }

        return $response;
    }

    // updating user GCM registration ID
    public function updateGcmID($user_id, $gcm_registration_id) 
            {
        $response = array();
        $stmt = $this->conn->prepare("UPDATE users SET gcm_registration_id = ? WHERE user_id = ?");
        $stmt->bind_param("si", $gcm_registration_id, $user_id);

        if ($stmt->execute()) {
            // User successfully updated
            $response["error"] = false;
            $response["message"] = 'GCM registration ID updated successfully';
        } else {
            // Failed to update user
            $response["error"] = true;
            $response["message"] = "Failed to update GCM registration ID";
            $stmt->error;
        }
        $stmt->close();

        return $response;
    }

    // fetching single user by id
    public function getUser($user_id) {
        $stmt = $this->conn->prepare("SELECT user_id, name, email, gcm_registration_id, created_at FROM users WHERE user_id = ?");
        $stmt->bind_param("s", $user_id);
        if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id, $name, $email, $gcm_registration_id, $created_at);
            $stmt->fetch();
            $user = array();
            $user["user_id"] = $user_id;
            $user["name"] = $name;
            $user["email"] = $email;
            $user["gcm_registration_id"] = $gcm_registration_id;
            $user["created_at"] = $created_at;
            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    }
    
    
    
     public function getUseruid($user_uid) {    
        $stmt = $this->conn->prepare("SELECT user_id,unique_id, name, email, gcm_registration_id, created_at FROM users WHERE unique_id = ?");
        $stmt->bind_param("s", $user_uid);
        if ($stmt->execute()) {
            //$user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id,$unique_id, $name, $email, $gcm_registration_id, $created_at);
            $stmt->fetch();
            $user = array();
            $user["user_id"] = $user_id;
            $user["user_uid"] = $unique_id;
            $user["name"] = $name;
            $user["email"] = $email;
            $user["gcm_registration_id"] = $gcm_registration_id;
            $user["created_at"] = $created_at;
            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    }

    // fetching multiple users by ids
    public function getUsers($user_ids) {

        $users = array();
        if (sizeof($user_ids) > 0) {
            $query = "SELECT user_id, name, email, gcm_registration_id, created_at FROM users WHERE user_id IN (";

            foreach ($user_ids as $user_id) {
                $query .= $user_id . ',';
            }

            $query = substr($query, 0, strlen($query) - 1);
            $query .= ')';

            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($user = $result->fetch_assoc()) {
                $tmp = array();
                $tmp["user_id"] = $user['user_id'];
                $tmp["name"] = $user['name'];
                $tmp["email"] = $user['email'];
                $tmp["gcm_registration_id"] = $user['gcm_registration_id'];
                $tmp["created_at"] = $user['created_at'];
                array_push($users, $tmp);
            }
        }

        return $users;
    }  


    /**
     * Checking for duplicate user by email address
     * @param String $email email to check in db
     * @return boolean
     */
    private function isUserExists($email) {
        $stmt = $this->conn->prepare("SELECT user_id from users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    /**
     * Fetching user by email
     * @param String $email User email id
     */
    public function getUserByEmail($email) 
            {
        $stmt = $this->conn->prepare("SELECT user_id, name, email, created_at FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id, $name, $email, $created_at);
            $stmt->fetch();
            $user = array();
            $user["user_id"] = $user_id;
            $user["name"] = $name;
            $user["email"] = $email;
            $user["created_at"] = $created_at;
            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    }
    
    public function getUserByEmail1($email) 
            {
        $stmt = $this->conn->prepare("SELECT user_id,unique_id, name, email, created_at FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id,$user_uid, $name, $email, $created_at);
            $stmt->fetch();
            $user = array();
            $user["user_id"] = $user_id;
            $user["user_uid"] = $user_uid;
            $user["name"] = $name;
            $user["email"] = $email;
            $user["created_at"] = $created_at;
            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    }
    
    /*
     * Get All users
     */
    public function getallUsers() {
        $users = array();
        
            $query = "SELECT * FROM users";
            //$stmt = $this->conn->prepare($query);
            //$stmt->execute();
            //$result = $stmt->get_result();
            $con=$this->conn;
            $result=mysqli_query($con, $query);
            while ($user = $result->fetch_assoc()) 
                    {
                $tmp = array();
                $tmp["user_id"] = $user['user_id'];
                $tmp["name"] = $user['name'];
                $tmp["email"] = $user['email'];
                $tmp["gcm_registration_id"] = $user['gcm_registration_id'];
                $tmp["created_at"] = $user['created_at'];
                array_push($users, $tmp);
            }
        return $users;
    }
    
    
    /*
     * Register
     */
    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($name, $email, $password) {
        $uuid = uniqid('', true);
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt

       $stmt = $this->conn->prepare("INSERT INTO users(unique_id, name, email, encrypted_password, salt, created_at) VALUES(?, ?, ?, ?, ?, NOW())");
       $stmt->bind_param("sssss", $uuid, $name, $email, $encrypted_password, $salt);
       $result1 = $stmt->execute();
       $stmt->close();
        // check for successful store
        if ($result1)
            {
            $query="SELECT * FROM users WHERE email ="."'".$email."'";
            $con=$this->conn;
            $user=mysqli_query($con, $query);
            return $user->fetch_assoc();
        } else {
            return false;
        }
    }

    /**
     * Get user by email and password
     */
    public function getUserByEmailAndPassword($email, $password) {

        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");

        $stmt->bind_param("s", $email);
        

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            $query="SELECT * FROM users WHERE email ="."'".$email."'";
            $con=$this->conn;
            $res=mysqli_query($con, $query);
             $user=$res->fetch_assoc();

            // verifying user password
            $salt = $user['salt'];
            $encrypted_password = $user['encrypted_password'];
            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
            if ($encrypted_password == $hash) {
                // user authentication details are correct
                return $user;
            }
        } else {
            return NULL; 
        }
    }

    public function adduser($email)
    {
        
    }


    /**
     * Check user is existed or not
     */
    public function isUserExisted($email) {
        $stmt = $this->conn->prepare("SELECT email from users WHERE email = ?");

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {

        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }

    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $password) {

        $hash = base64_encode(sha1($password . $salt, true) . $salt);

        return $hash;
    }
    
    /**
     * Storing new user
     * returns user details
     */
    public function storegps($user_id,$slagtitued, $slogtutid) {
        $uuid = uniqid('', true);
        $stmt = $this->conn->prepare("INSERT INTO gpsdata(user_id,unique_id,slagtitued, logtutid, created_at) VALUES(?,?, ?, ?,NOW())");
        $stmt->bind_param("ssss",$user_id,$uuid, $slagtitued, $slogtutid);
        $result = $stmt->execute();
        $result1['user_id']=$user_id;
        $result1['unique_id']=$uuid;
        $result1['slagtitued']=$slagtitued;
        $result1['slogtutid']=$slogtutid;
        $stmt->close();
        // check for successful store
        if ($result) {
            return $result1;
        } else {
            return $result1;
        }
    }
    
   public function userrequest($fromid,$toid)
   {
       $status="sending";
       $stmt = $this->conn->prepare("INSERT INTO request_details(from_id,  to_id, status, created_at, updated_at) values(?, ?, ?, NOW(), NOW())");
       $stmt->bind_param("sss",$fromid, $toid, $status);
        $result = $stmt->execute();
        $stmt->close();        
        if ($result) {            
            $response["error"] = false;
            $IDDD=$this->getUserrequestlast()-1;
            $response["request1"]=$IDDD;
            $response["request"] = $this->getUserrequest($IDDD);
            return $response;
        } else 
            {
            $response["error"] = true;
            $response["message"] = "Oops! An error occurred while registereing";
        }
   }
   
    public function getUserrequestlast() 
            {                
        $dbee=DB_NAME;
        $stmt = $this->conn->prepare("SHOW TABLE STATUS FROM ".$dbee);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row=$result->fetch_assoc()){
                      if (isset($row["Name"])== "request_details"){
                          $ai[$row["Name"]]=$row["Auto_increment"];
                    }
                }
       return $ai["request_details"];
    } 
    public function getUserrequest($id) 
            {        
        $stmt=$this->conn->prepare("SELECT id, from_id, to_id, status, created_at, updated_at from request_details WHERE id=?");
        $stmt->bind_param("s", $id);
        if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($id,$from_id, $to_id, $status, $created_at,$updated_at);
            $stmt->fetch();
            $user = array();
            $user["id"] = $id;
            $user["from_id"] = $from_id;
            $user["to_id"] = $to_id;
            $user["status"] = $status;
            $user["created_at"] = $created_at;
            $user["updated_at"] = $updated_at;
            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    } 
    
     public function updateuserreqstatus($req_id,$status) 
            {
        $response = array();
        $stmt = $this->conn->prepare("UPDATE request_details SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $req_id);
        if ($stmt->execute()) {
            $response["error"] = false;
            $response["message"] = 'Status Updated...';
        } else {
            // Failed to update user
            $response["error"] = true;
            $response["message"] = "Status Not Updated";
            $stmt->error;
        }
        $stmt->close();

        return $response;
    }
    
    public function creategroup($fromid,$toid)
   {
       $stmt = $this->conn->prepare("INSERT INTO groups(from_id,  to_id,created_at, updated_at) values(?, ?, NOW(), NOW())");
       $stmt->bind_param("ss",$fromid, $toid);
        $result = $stmt->execute();
        $stmt->close();        
        if ($result) {            
            $response["error"] = false;
            $IDDD=$this->getgroupslast()-1;
            $stmt = $this->conn->prepare("INSERT INTO connectedids(group_id,  user_uid,created_at, updated_at) values(?, ?, NOW(), NOW())");
            $stmt->bind_param("ss",$IDDD, $fromid);
            $result = $stmt->execute();
            $stmt->close();        
            $stmt = $this->conn->prepare("INSERT INTO connectedids(group_id,  user_uid,created_at, updated_at) values(?, ?, NOW(), NOW())");
            $stmt->bind_param("ss",$IDDD, $toid);
            $result = $stmt->execute();
            $response["request1"]=$IDDD;
            return $response;
        } else 
            {
            $response["error"] = true;
            $response["message"] = "Oops! An error occurred while registereing";
        }
   }
   
   public function getgroupslast() 
            {        
        $dbee=DB_NAME;
        $stmt = $this->conn->prepare("SHOW TABLE STATUS FROM ".$dbee);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row=$result->fetch_assoc()){
                      if (isset($row["Name"])== "groups"){
                          $ai[$row["Name"]]=$row["Auto_increment"];
                    }
                }
       return $ai["groups"];
    } 
    
    public function getallUsersrequest($userid) {
        $users = array();
            $query = "SELECT * FROM request_details WHERE ";
            $con=$this->conn;
            $result=mysqli_query($con, $query);
            while ($user = $result->fetch_assoc()) 
                    {
                        
                    }
        return $users;
    }
    
    public function getusergroups($uid)
    {
        //$uid="5845c7cfc5c8f6.40858900";
        $query="SELECT * FROM connectedids WHERE user_uid='".$uid."'";
        $con=$this->conn;
        $result=mysqli_query($con,$query);
        $rows = Array();
        while ($usergroup= $result->fetch_assoc()) {
        	 $tmp = array();
                $tmp = $usergroup['group_id'];
                array_push($rows, $tmp);
            }
            $rows1=array();
        for($i=0;$i< count($rows);$i++)
           {
                $tmp = array();
                $tmp1 = array();
                $sam =$this->getgrouprrequest($rows[$i]);
                $tmp=$sam[0];
                $tmp1=$sam[1];
                if($sam[0]==$uid)
                {
                     array_push($rows1, $tmp1);
                }
                else
                {
                     array_push($rows1, $tmp);
                }
           }
           
            $rows2=array();
        for($i=0;$i< count($rows1);$i++)
           {
                $tmp = array();
                $tmp=array($this->getUseruidreg($rows1[$i]),$rows[$i]);
                 array_push($rows2, $tmp);
           }
        return $rows2;

    }
    
     public function getUseruidreg($user_uid) {    
        $stmt = $this->conn->prepare("SELECT unique_id, gcm_registration_id FROM users WHERE unique_id = ?");
        $stmt->bind_param("s", $user_uid);
        if ($stmt->execute()) {
            $stmt->bind_result($unique_id,$gcm_registration_id);
            $stmt->fetch();
            $stmt->close();
            return $gcm_registration_id;
        } else {
            return NULL;
        }
    }
    
    public function getgrouprrequest($id) 
            {        
                    $query="SELECT * FROM connectedids WHERE group_id='".$id."'";
                    $con=$this->conn;
                    $result=mysqli_query($con,$query);
                     $rows = Array();
                    while ($usergroup= $result->fetch_assoc()) {
                             $tmp = array();
                            $tmp = $usergroup['user_uid'];
                            array_push($rows, $tmp);
                        }
                        return $rows;
            } 
    
   
}

?>
