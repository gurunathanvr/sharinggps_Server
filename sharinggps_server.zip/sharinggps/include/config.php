<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_NAME', 'sharing_gps');//android_api     gcm_chat

define("GOOGLE_API_KEY", "AIzaSyDEv6YuMDMkECagxniGUTPibhDXNM30nOY");
define('FIREBASE_API_KEY', 'AAAAw34Oia4:APA91bGGTYKHpuctp7qixclAiSVGINLSaIXw11kTMQ0T6V5ox5cUryRLpthB3_8LC7boIRy3u0juTjjHjICsdFNuG6CPURLVFpJ8UYASE_9lnk7kCEr7e-_QTFY_ntMLwbQs_eePjd_a1hFzyGoSoeaxTXfiPiYbwg');

// push notification flags
define('PUSH_FLAG_Request', 1);
define('PUSH_FLAG_response', 2);
define('PUSH_FLAG_USER', 3);

?>
