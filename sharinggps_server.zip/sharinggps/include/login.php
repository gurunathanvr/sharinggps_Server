<?php
require_once 'db_handler.php';
$lo=new DbHandler ();
$user =  $_POST['username'];
$pass =  $_POST['password'];
$user = $lo->getUserByEmailAndPassword($user, $pass);
if($user=="Error")
  {
    header("Location:../login.php");
  }
 else
 {
  session_start();   
  $_SESSION["OK"]="ok";
  $_SESSION["email"] = $user[3];
  header("Location:../index.php");
}
    
 ?>     