<?php

error_reporting(-1);
ini_set('display_errors', 'On');

require_once '../include/db_handler.php';
require '.././libs/Slim/Slim.php';

\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

// User login
$app->post('/user/login', function() use ($app) {
    // reading post params
    $email = $app->request->post('email');
    $password = $app->request->post('password');
    // validating email address
    validateEmail($email);
    $db = new DbHandler();
     $user = $db->getUserByEmailAndPassword($email, $password);
     if ($user != false) {
        $response["error"] = FALSE;
        $response["uid"] = $user["unique_id"];
        $response["user"]["user_id"] = $user["user_id"];
        $response["user"]["name"] = $user["name"];
        $response["user"]["email"] = $user["email"];
        $response["user"]["created_at"] = $user["created_at"];
        $response["user"]["updated_at"] = $user["updated_at"];
        echoRespnse(200, $response);
    } else {
        $response["error"] = TRUE;
        $response["error_msg"] = "Login credentials are wrong. Please try again!";
        $response["user"]=$user;
        echoRespnse(200, $response);
    }
    // echo json response
    //echoRespnse(200, $response);
});

$app->post('/user/register', function() use ($app) {
    
    $name = $app->request->post('name');
    $email = $app->request->post('email');
    $password = $app->request->post('password');
    // validating email address
    validateEmail($email);
    $db = new DbHandler();
     if ($db->isUserExisted($email)) {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "User already existed with " . $email;
       echoRespnse(200, $response);
    } else {
        // create a new user
        $user = $db->storeUser($name, $email, $password);
        if ($user) {
            // user stored successfully
            $response["error"] = FALSE;
            $response["uid"] = $user["unique_id"];
            $response["user"]["user_id"] = $user["user_id"];
            $response["user"]["name"] = $user["name"];
            $response["user"]["email"] = $user["email"];
            $response["user"]["created_at"] = $user["created_at"];
            $response["user"]["updated_at"] = $user["updated_at"];
            echoRespnse(200, $response);
        } else {
            // user failed to store
            $response["error"] = TRUE;
             $response["uid"]=$user;
            $response["error_msg"] = "Unknown error occurred in registration!";
            echoRespnse(200, $response);
        }
    }
    
});
/*
Check Email adduser
 *  */
$app->post('/user/adduser', function() use ($app) {
    // reading post params
    $email = $app->request->post('email');
    $requser_uid = $app->request->post('user_uid');
    
    // validating email address
    validateEmail($email);
    $db = new DbHandler();
     $user = $db->getUserByEmailAndPassword($email,  $requser_uid);
     
     if ($user != false) {        
        echoRespnse(200, $response);
    } else {
       
        echoRespnse(200, $response);
    }
    // echo json response
    //echoRespnse(200, $response);
});



/* * *
 * Updating user
 *  we use this url to update user's gcm registration id
 */
$app->put('/user/:id', function($user_id) use ($app) {
    global $app;

    verifyRequiredParams(array('gcm_registration_id'));

    $gcm_registration_id = $app->request->put('gcm_registration_id');

    $db = new DbHandler();
    $response = $db->updateGcmID($user_id, $gcm_registration_id);

    echoRespnse(200, $response);
});



$app->post('/storegps', function() use($app){
    
    global $app;
    $db = new DbHandler();
    $user_id=$app->request->post('user_id');
      
    $lagtitued = $app->request->post('slagtitued');
    $logtutid = $app->request->post('slogtutid'); 
    // Store The GPS Details
     $gps = $db->storegps($user_id,$lagtitued, $logtutid);
        if ($gps)
            {
            // user stored successfully
            $response["error"] = FALSE;
            $response["uid"] = $gps["unique_id"];
            $response["user"]["slagtitued"] = $gps["slagtitued"];
            $response["user"]["slogtutid"] = $gps["slogtutid"];
             $response["user"]["user_id"]=$gps["user_id"];
           echoRespnse(200, $response);
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in GPS Storeing!".$gps;
           echoRespnse(200, $response);
        }
    
});


/**
 * Verifying required params posted or not
 */
function verifyRequiredParams($required_fields) {
    $error = false;
    $error_fields = "";
    $request_params = array();
    $request_params = $_REQUEST;
    // Handling PUT request params
    if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
        $app = \Slim\Slim::getInstance();
        parse_str($app->request()->getBody(), $request_params);
    }
    foreach ($required_fields as $field) {
        if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }
    if ($error) {
        // Required field(s) are missing or empty
        // echo error json and stop the app
        $response = array();
        $app = \Slim\Slim::getInstance();
        $response["error"] = true;
        $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        echoRespnse(400, $response);
        $app->stop();
    }
}

/**
 * Validating email address
 */
function validateEmail($email) {
    $app = \Slim\Slim::getInstance();
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response["error"] = true;
        $response["message"] = 'Email address is not valid';
        echoRespnse(400, $response);
        $app->stop();
    }
}

function IsNullOrEmptyString($str) {
    return (!isset($str) || trim($str) === '');
}

/**
 * Echoing json response to client
 * @param String $status_code Http response code
 * @param Int $response Json response
 */
function echoRespnse($status_code, $response) {
    $app = \Slim\Slim::getInstance();
    // Http response code
    $app->status($status_code);

    // setting response content type to json
    $app->contentType('application/json');

    echo json_encode($response);
}
/*
 * Register ID , GPS Details 
 */

$app->post('/userrequest/', function() use ($app) {
    global $app;
    $db = new DbHandler();
    verifyRequiredParams(array('sender_id','email', 'receiver_message'));
    $sender_id = $app->request->post('sender_id');
    $toemail = $app->request->post('email');
    $message = $app->request->post('receiver_message');    
    $sender=$db->getUseruid($sender_id);
    $toemail1=$db->getUserByEmail1($toemail);
    if($toemail1["user_id"]==NULL)
    {
         $response['error'] = TRUE;  
         $response['message']="User Not Found....";
    }
    else
    {
        $response['error'] = false;  
        //$response['sender']=$sender;
        //$response['toemail']=$toemail1;       
    }    
    if ($response['error'] == false) {
        require_once __DIR__ . '/../libs/gcm/gcm.php';
        require_once __DIR__ . '/../libs/gcm/push.php';
        $gcm = new GCM();
        $push = new Push();        
        $user = $db->getUser($toemail1["user_id"]);
        $user1=$db->getUser($sender["user_id"]);
        $request=$db->userrequest($sender["user_uid"],$toemail1["user_uid"]);
        
        $data = array();
        $data['statustype']= "request";
        $data['user'] = $user['name'];
        $data['fromuser']=$user1['name'];
        $data['message'] = $message.$request['request1'];
        $data['requestid']= $request['request1'];
        $data['from_id']= $request["request"]['from_id'];
        $data['to_id']= $request["request"]['to_id'];
        $data['dbstatus']= $request["request"]['status'];
        $data["created_at"] =$request["request"]['created_at'];
        $data["updated_at"] =$request["request"]['updated_at'];
        $push->setTitle("Friend Request....");
        $push->setIsBackground(TRUE);
        $push->setMessage($message.$request['request1']);
        $push->setFlag(PUSH_FLAG_Request);
        $push->setPayload($data);
         $gcm->send($user['gcm_registration_id'], $push->getPush());   
        $response['data'] = $data;
        $response['error'] = false;
    }
    echoRespnse(200, $response);
});
$app->post('/userreqstatus/', function() use ($app) {
    global $app;
    $db = new DbHandler();
    verifyRequiredParams(array('sender_id','req_id','status'));
    $sender_id = $app->request->post('sender_id');
    $req_id = $app->request->post('req_id');
    $status=$app->request->post('status');
    $message=$status;
    $requestdetails=$db->getUserrequest($req_id);
    $sender=$db->getUseruid($sender_id);
    $toemail1=$db->getUseruid($requestdetails['to_id']);
    if($toemail1["user_id"]==NULL)
    {
         $response['error'] = TRUE;         
         $response['message']="User Not Found....";
    }
    else
    {
        $response['error'] = false;
    }    
    if ($response['error'] == false) {
        require_once __DIR__ . '/../libs/gcm/gcm.php';
        require_once __DIR__ . '/../libs/gcm/push.php';
        $gcm = new GCM();
        $push = new Push();        
        $user = $db->getUseruid($requestdetails['from_id']);
        $request=$db->updateuserreqstatus($req_id,$status);
        $groupid="";
        if($status=="accept")
        {
            $groupdetails=$db->creategroup($requestdetails['from_id'],$requestdetails['to_id']);
            $groupid=$groupdetails['request1'];
        }
        $data = array();       
        $data['status'] = $status;
        $data['request'] = $request;
        $data['requestid']= $req_id;
        $data['statustype']= "requestupdate";
        $data['user'] = $user['name'];
        $data['message'] = $message.$req_id;
        $data['requestid']= $req_id;
        $data['dbstatus']= $status;
        $data['groupid']=$groupid;
        $push->setTitle("Request Status Updates...");
        $push->setIsBackground(TRUE);
        $push->setMessage($message);
        $push->setFlag(PUSH_FLAG_Request);
        $push->setPayload($data);       
        $gcm->send($user['gcm_registration_id'], $push->getPush());        
        $response['error'] = false;
        $response['status']=$status;
        $response['requestid']=$req_id;
        $response['groupid'] = $groupid;
        $response['error'] = false;
    }
    echoRespnse(200, $response);
});

$app->post('/usergpsupdate/', function() use ($app) {
    global $app;
    $db = new DbHandler();
    verifyRequiredParams(array('user_uid','lat','log'));
    $user_uid = $app->request->post('user_uid');
    $lat = $app->request->post('lat');
    $log=$app->request->post('log');
    $response=$db->getusergroups($user_uid);
    $row=array();
   for($i=0;$i< count($response);$i++)//PUSH_FLAG_GPS
   {
        require_once __DIR__ . '/../libs/gcm/gcm.php';
        require_once __DIR__ . '/../libs/gcm/push.php';
        $gcm = new GCM();
        $push = new Push(); 
        $data['lat'] = $lat;
        $data['log']= $log;
        $data['guid']=$response[$i][1];
        $push->setTitle("Request Status Updates...");
        $push->setIsBackground(TRUE);
        $push->setMessage("GPS");
        $push->setFlag("4");
        $push->setPayload($data);      
        $res["gcmsta"]=$gcm->send($response[$i][0], $push->getPush()); 
   }
   $res['error']=false;
   $res['message']="ok";
   $res['data']=$data;
   echoRespnse(200, $res);
});

$app->run();
?>